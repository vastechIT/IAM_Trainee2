(function() {
   'use strict';
   var widgetFunction = function() {

      angular.module('sailpoint.home.desktop.app')
      .config(['$httpProvider',function($httpProvider) {
          $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";  		  
      }])
 
 
      .controller('accessReviewsPluginWidgetCtrl', ['$scope', '$http', function($scope, $http) {
        $scope.display_text = "Hello World"; 
   $scope.data = "";
  
   $scope.labels = ['Revoked', 'Approved', 'Pending'];
   $scope.status1 = "";
    $scope.callApi = function() { 
	   $http({
          method: "GET",
          // use PluginHelper to get full URL for rest call
          url: PluginHelper.getPluginRestUrl("AccessReviewStatus/get"), 
	   }).then(function successCallback(response) {
           try {
        	   let json = response.data;
               
               if (json === undefined || json.length == 0) {
             	  $scope.status1 = ["No matches found"]; 
               } else {
		          $scope.status1 = json;
		          $scope.data = [$scope.status1[0], $scope.status1[1], $scope.status1[2]];
		          $scope.getChart();
               }
           }  catch(err) {
               
               $scope.status1 = ["You asked to search for " ];
           } 
	    }, function errorCallback(response) {
	    	
		     $scope.status1 = response.status;
	    }) //end http .then
	    
	    
    };
   $scope.getChart = function() {
	   // Get the canvas element
    var ctx = document.getElementById('chart').getContext('2d');

    // Create the pie chart
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: $scope.labels,
            datasets: [{
                data: $scope.data,
                backgroundColor: [
                    'rgba(255, 99, 132, 0.7)',
                    'rgba(54, 162, 235, 0.7)',
                    'rgba(255, 206, 86, 0.7)',
                ],
                borderColor: [
                    'rgba(255, 99, 132, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false
        }
    });
   }
      $scope.callApi();

      }]) // End controller


      .directive('spAccessReviewsWidget', function() {
         // Insert directive definition here
            return {
	   	    restrict: 'E',              
		    controller: 'accessReviewsPluginWidgetCtrl',
            templateUrl:  PluginHelper.getPluginFileUrl('AccessReviewStatus', 'ui/html/accessReviewsWidgetTemplate.html')
   	     };
      
      }); // End directive

   }; // End widgetFunction

   // Adds widgetFunction to IdentityIQ
   PluginHelper.addWidgetFunction(widgetFunction);

})(); 
