angular.module('ApplicationStatusMonitorPlugin',['ui.bootstrap','sailpoint.dataview'])
.config(['$httpProvider',function($httpProvider) {
   $httpProvider.defaults.xsrfCookieName = "CSRF-TOKEN";  		  
}])
 
.controller('trainingPluginFullPageCtrl', ['$scope', function($scope){
   $scope.display_text = "Hello World"; 
   
   $scope.apps=["AD_Connector","FFServiceTest","Delimited_File_Connector"];
   
   
   
   $scope.status = null;
  
            
            
      $scope.getAppData = function(appName) {
		  $scope.status=appName; 
	   $http({
          method: "GET",
          // use PluginHelper to get full URL for rest call
          url: PluginHelper.getPluginRestUrl("ApplicationStatusMonitorPlugin/getAppData/"+appName), 
	   }).then(function successCallback(response) {
           try {
        	   let json = response.data;
               
               if (json === undefined || json.length == 0) {
             	  $scope.status = ["No matches found"]; 
               } else {
		          $scope.status = json;
               }
           }  catch(err) {
               
               $scope.status = ["You asked to search for " ];
           } 
	    }, function errorCallback(response) {
	    	
		     $scope.status = response.status;
	    }) //end http .then
	    
	    
    };  
    
        
  
}]);