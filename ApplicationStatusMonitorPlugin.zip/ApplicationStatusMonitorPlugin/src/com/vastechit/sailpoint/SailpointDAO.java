package com.vastechit.sailpoint;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Array;

import sailpoint.api.SailPointFactory;
import sailpoint.object.Identity;
import sailpoint.tools.GeneralException;
import sailpoint.connector.Connector;
import sailpoint.connector.ConnectorException;
import sailpoint.connector.ConnectorFactory;
import sailpoint.object.Application;
public class SailpointDAO {

	
	
	public String testConnection(String appName)  {
		  // Retrieve application object
		 Application app;
		try {
			app = (Application) SailPointFactory.getCurrentContext().getObjectByName(Application.class, "AD_Connector");
			
			 // Get the connector configuration
		     //   Connector connector = app.getConnector();
		    Connector connector = ConnectorFactory.getConnector(app, "sailpoint");
		   
            connector.testConfiguration();
            return "Connection successful.";
		       
		         
		        
		} catch (GeneralException | ConnectorException e) {
			// TODO Auto-generated catch block
			   return "Connection failed: " + e.getMessage();
		}

	       
	}
    
   

}
