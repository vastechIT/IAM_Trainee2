package com.vastechit.sailpoint;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import sailpoint.rest.plugin.AllowAll;
import sailpoint.tools.EmailException;
import sailpoint.tools.GeneralException;


@Path("ApplicationStatusMonitorPlugin")
@Produces("application/json")
@Consumes("application/json")
@AllowAll
public class Service {
	
	@GET
    @AllowAll
	@Path("getAppData/{appName}")
	public String testConnection(@PathParam("appName") String appName){
		System.out.println("dhchvc");
		System.out.println(appName);
		SailpointDAO dao=new SailpointDAO();
		return dao.testConnection(appName);
	}

}
